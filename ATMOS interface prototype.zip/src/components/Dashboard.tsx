import React, { useState, useEffect } from 'react';
import { 
  Sun, 
  Zap, 
  Activity, 
  AlertTriangle, 
  Factory, 
  Home, 
  Cpu, 
  Thermometer, 
  CloudRain, 
  Coins, 
  ArrowRightLeft, 
  ChevronLeft, 
  ChevronRight
} from 'lucide-react';
import { 
  AreaChart, 
  Area, 
  XAxis, 
  YAxis, 
  CartesianGrid, 
  Tooltip, 
  ResponsiveContainer,
  BarChart,
  Bar,
  Cell,
  LineChart,
  Line
} from 'recharts';
import { cn } from '../lib/utils';
import { fetchBahrainWeather, WeatherData } from '../services/weather';
import { motion, AnimatePresence } from 'motion/react';
import { format, addDays, isSameDay } from 'date-fns';

interface DashboardProps {
  view: 'home' | 'factory';
}

export default function Dashboard({ view }: DashboardProps) {
  const [weatherData, setWeatherData] = useState<WeatherData[]>([]);
  const [loading, setLoading] = useState(true);
  const [activeTab, setActiveTab] = useState<'generation' | 'cost'>('generation');
  const [selectedDate, setSelectedDate] = useState<Date>(new Date());
  
  // Solar System Configuration
  const [systemConfig, setSystemConfig] = useState({
    home: { count: 12, size: 400 }, // 4.8 kW
    factory: { count: 1200, size: 450 } // 540 kW
  });

  const currentConfig = systemConfig[view];

  // Hardware Sensor State (Simulated)
  const [sensors, setSensors] = useState({
    ldr: 850, // Lux
    dust: 12, // μg/m³
    temp: 34.5, // °C
    piStatus: 'Online',
    efficiency: 94.2
  });

  useEffect(() => {
    async function loadData() {
      const data = await fetchBahrainWeather(7);
      setWeatherData(data);
      setLoading(false);
    }
    loadData();
  }, []);

  // Update sensors periodically (Removed random updates)
  useEffect(() => {
    // Sensors remain stable based on initial state or weather
  }, []);

  // Sanity Check Algorithm (Simulated)
  const [sensorDrift, setSensorDrift] = useState(false);
  const [safeMode, setSafeMode] = useState(false);

  useEffect(() => {
    const interval = setInterval(() => {
      const drift = Math.random() > 0.9;
      setSensorDrift(drift);
      if (drift) setSafeMode(true);
      else setSafeMode(false);
    }, 20000);
    return () => clearInterval(interval);
  }, []);

  // Filter data for selected date
  const filteredData = weatherData.filter(d => isSameDay(new Date(d.date), selectedDate));

  // Grid Rate in BHD per kWh (Bahrain EWA approx)
  const GRID_RATE = 0.033; 

  // Simulate energy generation based on weather
  const chartData = filteredData.map(d => {
    // Calculate system capacity in kW
    const systemCapacityKw = (currentConfig.count * currentConfig.size) / 1000;
    
    // Solar generation (kW) = (Radiation / 1000) * Capacity * Efficiency
    // We assume a standard 85% system performance ratio (PR)
    let solarGen = (d.solarRadiation / 1000) * systemCapacityKw * 0.85;
    
    // Apply drift if active
    if (sensorDrift && !safeMode) {
      solarGen *= 1.6; 
    }

    // Stable load based on time of day and view
    const hour = new Date(d.date + ' ' + d.time).getHours();
    const baseLoad = view === 'factory' ? 450 : 3.5;
    const timeMultiplier = 0.7 + Math.sin((hour / 24) * Math.PI) * 0.6; // Peak during day
    const load = baseLoad * timeMultiplier;
    
    const gridUsage = Math.max(0, load - solarGen);
    const solarUsage = Math.min(load, solarGen);
    const savings = solarUsage * GRID_RATE;
    
    return {
      ...d,
      solarGen: parseFloat(solarGen.toFixed(2)),
      load: parseFloat(load.toFixed(2)),
      gridUsage: parseFloat(gridUsage.toFixed(2)),
      solarUsage: parseFloat(solarUsage.toFixed(2)),
      savings: parseFloat(savings.toFixed(2)),
      net: parseFloat((solarGen - load).toFixed(2))
    };
  });

  const currentHour = new Date().getHours();
  const currentStats = chartData[currentHour] || chartData[0];
  
  const totalSavings = chartData.reduce((acc, curr) => acc + curr.savings, 0);
  const totalSolarGen = chartData.reduce((acc, curr) => acc + curr.solarGen, 0);

  const dates = Array.from({ length: 7 }, (_, i) => addDays(new Date(), i));

  if (loading) {
    return (
      <div className="flex items-center justify-center h-full">
        <motion.div 
          animate={{ rotate: 360 }}
          transition={{ repeat: Infinity, duration: 1, ease: "linear" }}
        >
          <Zap className="w-8 h-8 text-emerald-500" />
        </motion.div>
      </div>
    );
  }

  return (
    <div className="p-6 space-y-6 max-w-7xl mx-auto">
      {/* Date Selector */}
      <div className="flex items-center gap-2 overflow-x-auto pb-2 scrollbar-hide">
        {dates.map((date, i) => (
          <button
            key={i}
            onClick={() => setSelectedDate(date)}
            className={cn(
              "flex flex-col items-center min-w-[80px] p-3 rounded-2xl border transition-all",
              isSameDay(date, selectedDate) 
                ? "bg-emerald-600 border-emerald-600 text-white shadow-lg shadow-emerald-200" 
                : "bg-white border-slate-100 text-slate-600 hover:border-emerald-200"
            )}
          >
            <span className="text-[10px] font-bold uppercase opacity-70">{format(date, 'EEE')}</span>
            <span className="text-lg font-bold">{format(date, 'dd')}</span>
          </button>
        ))}
      </div>

      {/* Header Stats */}
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-4">
        <StatsCard 
          title="Solar Generation" 
          value={`${currentStats?.solarGen || 0} kW`} 
          icon={<Sun className="w-5 h-5 text-amber-500" />}
          trend={safeMode ? "API SAFE MODE" : `CAP: ${(currentConfig.count * currentConfig.size / 1000).toFixed(1)}kW`}
          trendUp={!safeMode}
          alert={safeMode}
        />
        <StatsCard 
          title="Daily Savings" 
          value={`${totalSavings.toFixed(3)} BHD`} 
          icon={<Coins className="w-5 h-5 text-emerald-500" />}
          trend="Estimated"
        />
        <StatsCard 
          title="Panel Efficiency" 
          value={`${sensors.efficiency.toFixed(1)}%`} 
          icon={<Activity className="w-5 h-5 text-blue-500" />}
          status={sensors.efficiency > 90 ? 'healthy' : 'warning'}
        />
        <StatsCard 
          title="Grid Status" 
          value={currentStats?.gridUsage > 0 ? "Active" : "Idle"} 
          icon={<Zap className="w-5 h-5 text-rose-500" />}
          trend={currentStats?.gridUsage > 0 ? "Supplementing" : "Self-Sufficient"}
        />
      </div>

      {safeMode && (
        <motion.div 
          initial={{ opacity: 0, y: -10 }}
          animate={{ opacity: 1, y: 0 }}
          className="bg-amber-50 border border-amber-200 p-4 rounded-xl flex items-center gap-3 text-amber-800"
        >
          <AlertTriangle className="w-5 h-5 shrink-0" />
          <div className="text-sm">
            <p className="font-bold">Sanity Check Triggered</p>
            <p>Hyperlocal sensor deviation &gt;50% detected. System has defaulted to <strong>Open-Meteo API Safe Mode</strong> for prediction accuracy.</p>
          </div>
        </motion.div>
      )}

      {/* Main Chart */}
      <div className="bg-white p-6 rounded-2xl shadow-sm border border-slate-100">
        <div className="flex items-center justify-between mb-6">
          <div>
            <h3 className="text-lg font-semibold text-slate-900">Energy Optimization</h3>
            <p className="text-sm text-slate-500">Solar Generation vs Grid Supplement (BHD Savings Focus)</p>
          </div>
          <div className="flex bg-slate-100 p-1 rounded-lg">
            <button 
              onClick={() => setActiveTab('generation')}
              className={cn(
                "px-4 py-1.5 text-sm font-medium rounded-md transition-all",
                activeTab === 'generation' ? "bg-white text-slate-900 shadow-sm" : "text-slate-500 hover:text-slate-700"
              )}
            >
              Solar Output
            </button>
            <button 
              onClick={() => setActiveTab('cost')}
              className={cn(
                "px-4 py-1.5 text-sm font-medium rounded-md transition-all",
                activeTab === 'cost' ? "bg-white text-slate-900 shadow-sm" : "text-slate-500 hover:text-slate-700"
              )}
            >
              Cost Savings
            </button>
          </div>
        </div>
        
        <div className="h-[350px] w-full">
          <ResponsiveContainer width="100%" height="100%">
            <AreaChart data={chartData}>
              <defs>
                <linearGradient id="colorSolar" x1="0" y1="0" x2="0" y2="1">
                  <stop offset="5%" stopColor="#f59e0b" stopOpacity={0.1}/>
                  <stop offset="95%" stopColor="#f59e0b" stopOpacity={0}/>
                </linearGradient>
                <linearGradient id="colorGrid" x1="0" y1="0" x2="0" y2="1">
                  <stop offset="5%" stopColor="#ef4444" stopOpacity={0.1}/>
                  <stop offset="95%" stopColor="#ef4444" stopOpacity={0}/>
                </linearGradient>
              </defs>
              <CartesianGrid strokeDasharray="3 3" vertical={false} stroke="#f1f5f9" />
              <XAxis 
                dataKey="time" 
                axisLine={false} 
                tickLine={false} 
                tick={{ fill: '#64748b', fontSize: 12 }}
                minTickGap={30}
              />
              <YAxis 
                axisLine={false} 
                tickLine={false} 
                tick={{ fill: '#64748b', fontSize: 12 }}
                unit={activeTab === 'cost' ? " BHD" : " kW"}
              />
              <Tooltip 
                contentStyle={{ borderRadius: '12px', border: 'none', boxShadow: '0 4px 12px rgba(0,0,0,0.1)' }}
              />
              {activeTab === 'generation' ? (
                <>
                  <Area type="monotone" dataKey="solarGen" stroke="#f59e0b" fillOpacity={1} fill="url(#colorSolar)" strokeWidth={2} name="Solar Gen" />
                  <Area type="monotone" dataKey="gridUsage" stroke="#ef4444" fillOpacity={1} fill="url(#colorGrid)" strokeWidth={2} name="Grid Usage" />
                </>
              ) : (
                <>
                  <Area type="monotone" dataKey="savings" stroke="#10b981" fillOpacity={1} fill="url(#colorSolar)" strokeWidth={2} name="Savings (BHD)" />
                  <Line type="monotone" dataKey="load" stroke="#3b82f6" strokeWidth={2} dot={false} name="Total Load" />
                </>
              )}
            </AreaChart>
          </ResponsiveContainer>
        </div>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
        {/* Hardware Sensor Suite */}
        <div className="lg:col-span-2 bg-white p-6 rounded-2xl shadow-sm border border-slate-100">
          <div className="flex items-center justify-between mb-6">
            <div className="flex items-center gap-2">
              <Cpu className="w-5 h-5 text-blue-600" />
              <h3 className="text-lg font-semibold text-slate-900">Hardware Sensor Suite</h3>
            </div>
            <div className="flex items-center gap-2">
              <span className="w-2 h-2 bg-emerald-500 rounded-full animate-pulse" />
              <span className="text-xs font-bold text-slate-500">RPi 4B: {sensors.piStatus}</span>
            </div>
          </div>
          
          <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
            <SensorMetric 
              label="LDR Intensity" 
              value={`${sensors.ldr.toFixed(0)} Lux`} 
              icon={<Sun className="w-4 h-4" />} 
              color="amber"
            />
            <SensorMetric 
              label="Thermal Probe" 
              value={`${sensors.temp.toFixed(1)}°C`} 
              icon={<Thermometer className="w-4 h-4" />} 
              color="rose"
            />
            <SensorMetric 
              label="Dust Level" 
              value={`${sensors.dust.toFixed(1)} μg`} 
              icon={<CloudRain className="w-4 h-4" />} 
              color="slate"
            />
            <SensorMetric 
              label="LoRa Link" 
              value="98% RSSI" 
              icon={<Activity className="w-4 h-4" />} 
              color="emerald"
            />
          </div>

          <div className="mt-8 p-4 bg-slate-50 rounded-xl border border-slate-100">
            <div className="flex items-center gap-3 mb-4">
              <ArrowRightLeft className="w-5 h-5 text-emerald-600" />
              <h4 className="font-bold text-slate-900">Switching Guide (Solar vs Grid)</h4>
            </div>
            <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
              <div className="p-3 bg-white rounded-lg border border-emerald-100">
                <p className="text-xs font-bold text-emerald-700 uppercase mb-1">Solar Priority</p>
                <p className="text-sm text-slate-600">Current generation covers 100% of load. Grid is on standby.</p>
              </div>
              <div className="p-3 bg-white rounded-lg border border-amber-100">
                <p className="text-xs font-bold text-amber-700 uppercase mb-1">Grid Supplement</p>
                <p className="text-sm text-slate-600">Load exceeds solar by {Math.max(0, currentStats?.load - currentStats?.solarGen).toFixed(2)} kW. Drawing from EWA.</p>
              </div>
            </div>
          </div>
        </div>

        {/* Efficiency Breakdown */}
        <div className="bg-white p-6 rounded-2xl shadow-sm border border-slate-100">
          <h3 className="text-lg font-semibold text-slate-900 mb-6">Efficiency Breakdown</h3>
          <div className="space-y-6">
            <HealthItem 
              label="PV Panel Efficiency" 
              status={sensors.efficiency > 90 ? "Normal" : "Warning"} 
              efficiency={`${sensors.efficiency.toFixed(1)}%`} 
              icon={<Sun className="w-4 h-4" />} 
            />
            <HealthItem 
              label="Inverter Performance" 
              status="Normal" 
              efficiency="96.8%" 
              icon={<Zap className="w-4 h-4" />} 
            />
            <HealthItem 
              label="Dust Impact" 
              status={sensors.dust > 15 ? "Warning" : "Minimal"} 
              efficiency={`${(100 - sensors.dust).toFixed(1)}%`} 
              icon={<Activity className="w-4 h-4" />} 
              warning={sensors.dust > 15 ? "Cleaning recommended" : undefined}
            />
            <div className="pt-4 border-t border-slate-100">
              <div className="bg-emerald-50 p-3 rounded-xl mb-4">
                <p className="text-xs font-bold text-emerald-800 mb-1">Cost Saving Tip</p>
                <p className="text-[10px] text-emerald-700">Shift heavy loads to 11:00 AM - 2:00 PM to maximize solar utilization and save ~0.450 BHD daily.</p>
              </div>
              <button className="w-full py-2.5 bg-slate-900 text-white rounded-xl text-sm font-medium hover:bg-slate-800 transition-colors">
                Export Savings Report
              </button>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}

function SensorMetric({ label, value, icon, color }: any) {
  const colors: any = {
    amber: "text-amber-600 bg-amber-50",
    rose: "text-rose-600 bg-rose-50",
    slate: "text-slate-600 bg-slate-50",
    emerald: "text-emerald-600 bg-emerald-50",
    blue: "text-blue-600 bg-blue-50"
  };
  
  return (
    <div className="p-3 rounded-xl border border-slate-100 bg-white">
      <div className={cn("w-8 h-8 rounded-lg flex items-center justify-center mb-2", colors[color])}>
        {icon}
      </div>
      <p className="text-[10px] font-bold text-slate-400 uppercase">{label}</p>
      <p className="text-sm font-bold text-slate-900">{value}</p>
    </div>
  );
}

function StatsCard({ title, value, icon, trend, trendUp, status, alert }: any) {
  return (
    <div className={cn(
      "bg-white p-5 rounded-2xl shadow-sm border transition-all",
      alert ? "border-amber-200 bg-amber-50/30" : "border-slate-100"
    )}>
      <div className="flex items-center justify-between mb-3">
        <div className={cn(
          "p-2 rounded-lg",
          alert ? "bg-amber-100" : "bg-slate-50"
        )}>
          {icon}
        </div>
        {trend && (
          <span className={cn(
            "text-[10px] font-bold px-2 py-0.5 rounded-full uppercase tracking-wider",
            alert ? "bg-amber-200 text-amber-800" :
            trendUp === true ? "bg-emerald-50 text-emerald-700" : 
            trendUp === false ? "bg-rose-50 text-rose-700" : "bg-slate-100 text-slate-600"
          )}>
            {trend}
          </span>
        )}
        {status && (
          <div className="flex items-center gap-1.5">
            <div className={cn(
              "w-2 h-2 rounded-full animate-pulse",
              status === 'healthy' ? "bg-emerald-500" : 
              status === 'warning' ? "bg-amber-500" : "bg-rose-500"
            )} />
            <span className="text-xs font-medium text-slate-600 capitalize">{status}</span>
          </div>
        )}
      </div>
      <div>
        <p className="text-sm text-slate-500 font-medium">{title}</p>
        <p className="text-2xl font-bold text-slate-900 mt-1">{value}</p>
      </div>
    </div>
  );
}

function HealthItem({ label, status, efficiency, icon, warning }: any) {
  return (
    <div className="space-y-2">
      <div className="flex items-center justify-between">
        <div className="flex items-center gap-2 text-slate-700">
          {icon}
          <span className="text-sm font-medium">{label}</span>
        </div>
        <span className={cn(
          "text-[10px] font-bold uppercase tracking-wider px-2 py-0.5 rounded",
          status === 'Normal' ? "bg-emerald-100 text-emerald-700" : "bg-amber-100 text-amber-700"
        )}>
          {status}
        </span>
      </div>
      <div className="flex items-center gap-3">
        <div className="flex-1 h-1.5 bg-slate-100 rounded-full overflow-hidden">
          <div 
            className={cn(
              "h-full rounded-full transition-all duration-1000",
              status === 'Normal' ? "bg-emerald-500" : "bg-amber-500"
            )} 
            style={{ width: efficiency }} 
          />
        </div>
        <span className="text-xs font-semibold text-slate-600">{efficiency}</span>
      </div>
      {warning && (
        <div className="flex items-center gap-1.5 text-amber-600">
          <AlertTriangle className="w-3 h-3" />
          <span className="text-[10px] font-medium">{warning}</span>
        </div>
      )}
    </div>
  );
}
