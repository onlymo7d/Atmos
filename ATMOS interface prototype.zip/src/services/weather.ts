export interface WeatherData {
  temperature: number;
  solarRadiation: number;
  cloudCover: number;
  time: string;
  date: string;
}

export async function fetchBahrainWeather(days: number = 7): Promise<WeatherData[]> {
  // Manama, Bahrain: 26.2285, 50.5860
  const url = `https://api.open-meteo.com/v1/forecast?latitude=26.2285&longitude=50.5860&hourly=temperature_2m,shortwave_radiation,cloud_cover&forecast_days=${days}`;
  
  try {
    const response = await fetch(url);
    const data = await response.json();
    
    return data.hourly.time.map((time: string, index: number) => {
      const dateObj = new Date(time);
      return {
        time: dateObj.toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' }),
        date: dateObj.toISOString().split('T')[0],
        temperature: data.hourly.temperature_2m[index],
        solarRadiation: data.hourly.shortwave_radiation[index],
        cloudCover: data.hourly.cloud_cover[index],
      };
    });
  } catch (error) {
    console.error("Failed to fetch weather data", error);
    return [];
  }
}
